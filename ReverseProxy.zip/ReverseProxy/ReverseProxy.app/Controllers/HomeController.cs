﻿using Microsoft.AspNetCore.Mvc;

namespace ReverseProxy.app.Controllers
{
    [ApiController]
    public class HomeController : ControllerBase
    {
        [HttpGet]
        [Route("api/security")]
        public IActionResult Security()
        {
            return Ok("security validated");
        }

        [HttpGet]
        [Route("api/notification")]
        public IActionResult Notification()
        {
            return Ok("notification trigged");
        }
    }
}
